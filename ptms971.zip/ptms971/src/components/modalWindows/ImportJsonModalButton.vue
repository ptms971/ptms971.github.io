<script setup>
import BsButtonForModal from "./BsButtonForModal.vue";
</script>
<template>
    <BsButtonForModal target-modal-id="importJsonModal">
        <slot/>
    </BsButtonForModal>
</template>